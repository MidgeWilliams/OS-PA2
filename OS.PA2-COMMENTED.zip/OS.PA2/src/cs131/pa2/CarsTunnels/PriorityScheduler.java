package cs131.pa2.CarsTunnels;

import java.util.*;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import cs131.pa2.Abstract.*;
import cs131.pa2.Abstract.Log.*;

public class PriorityScheduler extends Tunnel {
	private final Lock lock = new ReentrantLock();
	private final Condition exitedFromTunnel = lock.newCondition();
	private Collection<Tunnel> tunnels;
	private ArrayList<ArrayList<Vehicle>> priority;
	private HashMap<Vehicle, Tunnel> vehicleMap;

	/**
	 * @param name
	 */
	public PriorityScheduler(String name) {
		super(name);
		tunnels = new ArrayList<>();
		vehicleMap = new HashMap<>();
		makePriorityLists();
	}

	/**
	 * @param name
	 * @param tunnels
	 * @param log
	 */
	public PriorityScheduler(String name, Collection<Tunnel> tunnels, Log log) {
		super(name, log);
		this.tunnels = tunnels;
		vehicleMap = new HashMap<>();
		makePriorityLists();// set up priority list
	}
	
	/**
	 * Makes the sub arrays that will be each level of priority (0-4)
	 */
	private void makePriorityLists() {
		priority = new ArrayList<ArrayList<Vehicle>>();
		for (int i = 0; i < 5; i++) {
			priority.add(new ArrayList<>());
		}
	}

	/**
	 * Sees if a given vehicle can enter any of the available tunnels, enters it if it is able. 
	 */
	@Override
	public boolean tryToEnterInner(Vehicle vehicle) {
			lock.lock();
			int currPr = vehicle.getPriority();
			if (!priority.get(currPr).contains(vehicle)) {
				priority.get(currPr).add(vehicle);
			}
			while (!checkHighPrior(currPr) || !checkTunnels(vehicle)) {// if its not its turn or if it can't go in
				try {
					exitedFromTunnel.await();//Wait until someone exits and it's possible they could enter
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					lock.unlock(); //Unlocks if something goes wrong
				}
			}
			priority.get(currPr).remove(vehicle); //It's in if it got this far, take it out of list
			lock.unlock();
			return true; //Returns true to say it got in
		}


	/**
	 * breaks loop by returning false if the vehicle entered
	 * 
	 * @param vehicle
	 * @return
	 */
	private boolean checkTunnels(Vehicle vehicle) {
		for (Tunnel tunnel : tunnels) {
			if (tunnel.tryToEnter(vehicle)) {// use try to enter/exit inner
				// add to tunnel map
				vehicleMap.put(vehicle, tunnel);// if it enters the tunnel remember which tunnel
				return true;
			}
		}
		return false;
	}

	/**
	 * returns true if its its turn goes from max to before curr
	 * 
	 * @param curr
	 * @return
	 */
	private boolean checkHighPrior(int curr) {
		for (int i = 4; i > curr; i--) {
			if (!priority.get(i).isEmpty()) {
				return false;// if not empty return false
			}
		}
		return true;// if all before are true return true
	}

	@Override
	public void exitTunnelInner(Vehicle vehicle) {
		lock.lock();
		Tunnel correctTunnel = vehicleMap.get(vehicle); //Gets the correct tunnel
		correctTunnel.exitTunnelInner(vehicle); //Exits BasicTunnel
		vehicleMap.remove(vehicle); //Take vehicle out
		exitedFromTunnel.signalAll(); //Signals there's a new spot
		lock.unlock();
	}

}