COSI 131 PA2 Task 1
Coded by Marguerite Williams and Benjamin Siege
