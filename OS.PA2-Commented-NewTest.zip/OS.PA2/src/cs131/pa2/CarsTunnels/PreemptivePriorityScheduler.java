package cs131.pa2.CarsTunnels;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;
import cs131.pa2.Abstract.Log.Log;

/**
 * 
 * @author Marguerite Williams
 * @author Ben Siege
 * 
 * Preemptive Priority Scheduler 
 * COSI 131; PA2 Task 2b
 */
public class PreemptivePriorityScheduler extends Tunnel{
	private final Lock lock = new ReentrantLock();
	private final Condition exitedFromTunnel = lock.newCondition();
	private Collection<Tunnel> tunnels;				//All of the tunnels
	private ArrayList<ArrayList<Vehicle>> priority; //Priority; Has 5 arrays, with the index being the priority of the vehicles in it
	private HashMap<Vehicle, Tunnel> vehicleMap;    //Maps the vehicles to which tunnel they are in
	private ArrayList<Tunnel> tunnelsWithAmb;		//Tunnels that currently have ambulances 
	private HashMap<Tunnel, Lock> ambLocks;			//Maps tunnels to the lock controlling their vehicles
	private HashMap<Lock, ArrayList<Condition>> ambConditions;	//Maps each lock to its conditions
	
	/**
	 * Constructor when given tunnels and log, initializes all of the variables
	 * 
	 * @param name Name of Scheduler
	 * @param tunnels A set of tunnels for cars to try
	 * @param log The log for tracking correctness
	 */
	public PreemptivePriorityScheduler(String name, Collection<Tunnel> tunnels, Log log) {
		super(name, log);
		this.tunnels = tunnels;
		this.vehicleMap = new HashMap<>();
		this.tunnelsWithAmb = new ArrayList<>();
		this.ambLocks = new HashMap<>();
		this.ambConditions = new HashMap<>();
		makePriorityLists();
		for (Tunnel tunnel : tunnels) {
			generateLockConditions(tunnel);//generates lock conditions for ambulances for each tunnel
		}
	}
	
	/**
	 * Constructor when only given name, initializes all of the variables
	 * 
	 * @param name
	 */
	public PreemptivePriorityScheduler(String name) {
		super(name);
		this.tunnels = new ArrayList<>();
		this.vehicleMap = new HashMap<>();
		this.tunnelsWithAmb = new ArrayList<>();
		this.ambLocks = new HashMap<>();
		this.ambConditions = new HashMap<>();
		makePriorityLists();
	}

	/**
	 * Sees if a given vehicle can enter any of the available tunnels, enters it if it is able. 
	 */
	@Override
	public boolean tryToEnterInner(Vehicle vehicle) {
			lock.lock();
			int currPr = vehicle.getPriority();
			if (!priority.get(currPr).contains(vehicle)) { //Adds to its priority list if it isn't already in it
				priority.get(currPr).add(vehicle);
			}
			while (!checkHighPrior(currPr) || !checkTunnels(vehicle)) {// if its not its turn or if it can't go in
				try {
					exitedFromTunnel.await(); //Wait for someone to exit a tunnel, once someone does it might be able to get in. 
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					lock.unlock(); //If there's a mistake automatically release the lock
				}
			}
			//If it gets this far, it has entered a tunnel
			priority.get(currPr).remove(vehicle); //Takes it off of the priority list
			lock.unlock(); //Unlocks
			return true;

	}
	
	/**
	 * Exits a tunnel. 
	 */
	@Override
	public void exitTunnelInner(Vehicle vehicle) {
		lock.lock(); 
		Tunnel correctTunnel = vehicleMap.get(vehicle); //Gets the tunnel it is exiting from
		correctTunnel.exitTunnelInner(vehicle); //Exits the Basic Tunnel
		vehicleMap.remove(vehicle); //Takes it out of map (since it isn't in a tunnel)
		
		if(vehicle instanceof Ambulance) { 
			Lock ambsLock = ambLocks.get(correctTunnel); //Get's it's lock and locks it while it plays with conditional variables
			ambsLock.lock();
			tunnelsWithAmb.remove(correctTunnel); //Takes tunnel off list of tunnels containing ambulances (since the ambulance exited)
			ambConditions.get(ambsLock).get(1).signalAll(); //Signals that it has exited, allowing vehicles to continue as normal
			ambsLock.unlock();	
		}
		exitedFromTunnel.signalAll(); //Signals that a vehicle exited
		lock.unlock();
	}
	
	/**
	 * Makes the sub arrays that will be each level of priority (0-4)
	 */
	private void makePriorityLists() {
		priority = new ArrayList<ArrayList<Vehicle>>();
		for (int i = 0; i < 5; i++) {
			priority.add(new ArrayList<>());
		}
	}
	
	/**
	 * Checks to see if there are vehicles of a higher priority waiting already.
	 * 
	 * @param curr The priority of the vehicle being checked
	 * @returnIf there are any higher priority vehicles returns false, otherwise true
	 */
	private boolean checkHighPrior(int curr) {
		for (int i = 4; i > curr; i--) { //Goes from highest priority down to the one being checked for. 
			if (!priority.get(i).isEmpty()) {
				return false;// if not empty return false
			}
		}
		return true;// if all before are true return true
	}
	
	/**
	 * Goes through each tunnel available and enters if it is able. 
	 * 
	 * @param vehicle Vehicle that wants to enter
	 * @return true if entered a tunnel, false if it didn't
	 */
	private boolean checkTunnels(Vehicle vehicle) {
		for (Tunnel tunnel : tunnels) {
			lock.lock(); //Locks so no other vehicle can try to enter this tunnel
			if (!this.tunnelsWithAmb.contains(tunnel)&&tunnel.tryToEnter(vehicle)) { //If this tunnel doens't have an ambulance AND it gets in
				// add to tunnel map
				vehicleMap.put(vehicle, tunnel);// if it enters the tunnel remember which tunnel
				if(vehicle instanceof Ambulance) { //If it's an ambulance entering
					Lock ambsLock = ambLocks.get(tunnel); 
					ambsLock.lock(); //Locks the tunnel while conditions are being altered
					this.tunnelsWithAmb.add(tunnel); 
					ambConditions.get(ambsLock).get(0).signalAll(); //Signals all vehicles that an ambulance has entered and to act accordingly
					ambsLock.unlock();	//Unlocks				
				}else {
					addLockConditionsToVehicle(vehicle, tunnel);
				}
				lock.unlock();
				return true; //Releases lock and returns true
			}
			lock.unlock(); //Releases lock each time it can't get in
		}
		return false; //Returns false if it never got into a tunnel
	}
	
	/**
	 * Creates a lock and condition variables for each tunnel, these will be used to "tell" any vehicles 
	 * in tunnel when an ambulance enters or exits
	 * 
	 * @param tunnel 
	 */
	private void generateLockConditions(Tunnel tunnel) {
		Lock lock = new ReentrantLock();
		ArrayList<Condition> ambConds = new ArrayList<>();
		ambConds.add(0, lock.newCondition());//entry condition
		ambConds.add(1, lock.newCondition());//exit condition
		this.ambLocks.put(tunnel, lock);
		this.ambConditions.put(lock, ambConds);
	}
	
	/**
	 * Gives the vehicle access to the locks the ambulances will use to signal entrance and exit to that tunnel
	 * @param vehicle Vehicle that goes into tunnel
	 * @param tunnel Tunnel so it can have specific locks
	 */
	private void addLockConditionsToVehicle(Vehicle vehicle, Tunnel tunnel) {
		Lock lock = this.ambLocks.get(tunnel);
		ArrayList<Condition> condList = this.ambConditions.get(lock);
		vehicle.setLockConditions(lock,condList.get(0),condList.get(1));
	}
	

	

	
}

