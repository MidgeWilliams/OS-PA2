COSI 131 Programming Assignment 2
Task 2

Marguerite Williams and Ben Siege

For Task 2b we had to change BasicTunnel because our if statement in tryToEnterInner did not originally take ambulences into account.