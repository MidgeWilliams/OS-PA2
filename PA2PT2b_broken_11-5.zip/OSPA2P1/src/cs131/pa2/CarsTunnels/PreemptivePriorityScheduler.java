package cs131.pa2.CarsTunnels;

import java.awt.List;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import cs131.pa2.Abstract.Tunnel;
import cs131.pa2.Abstract.Vehicle;
import cs131.pa2.Abstract.Log.Log;

public class PreemptivePriorityScheduler extends Tunnel{
	private final Lock lock = new ReentrantLock();
	private final Condition exitedFromTunnel = lock.newCondition();
	private Collection<Tunnel> tunnels;
	private ArrayList<ArrayList<Vehicle>> priority;
	private HashMap<Vehicle, Tunnel> vehicleMap;
	private ArrayList<Tunnel> tunnelsWithAmb;
	private HashMap<Tunnel, Lock> ambLocks;
	private HashMap<Lock, ArrayList<Condition>> ambConditions;
	
	public PreemptivePriorityScheduler(String name, Collection<Tunnel> tunnels, Log log) {
		super(name, log);
		this.tunnels = tunnels;
		this.vehicleMap = new HashMap<>();
		this.tunnelsWithAmb = new ArrayList<>();
		this.ambLocks = new HashMap<>();
		this.ambConditions = new HashMap<>();
		makePriorityLists();
		for (Tunnel tunnel : tunnels) {
			generateLockConditions(tunnel);//generates lock conditions for ambulances for each tunnel
		}
	}
	public PreemptivePriorityScheduler(String name) {
		super(name);
		this.tunnels = new ArrayList<>();
		this.vehicleMap = new HashMap<>();
		this.tunnelsWithAmb = new ArrayList<>();
		this.ambLocks = new HashMap<>();
		this.ambConditions = new HashMap<>();
		makePriorityLists();
	}

	
	@Override
	public boolean tryToEnterInner(Vehicle vehicle) {
			lock.lock();
			int currPr = vehicle.getPriority();
			if (!priority.get(currPr).contains(vehicle)) {
				priority.get(currPr).add(vehicle);
			}
			while (!checkHighPrior(currPr) || !checkTunnels(vehicle)) {// if its not its turn or if it can't go in
				try {
					exitedFromTunnel.await();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					lock.unlock();
				}
			}
			// need to put successful entry code in else block,
			priority.get(currPr).remove(vehicle);
			lock.unlock();
			return true;

	}
	
	@Override
	public void exitTunnelInner(Vehicle vehicle) {
		lock.lock();
		Tunnel correctTunnel = vehicleMap.get(vehicle);
		correctTunnel.exitTunnelInner(vehicle);
		vehicleMap.remove(vehicle);
		if(vehicle instanceof Ambulance) { 
			tunnelsWithAmb.remove(correctTunnel);
			ambConditions.get(ambLocks.get(correctTunnel)).get(1).signalAll();//wake up all in associated tunnel that amb is leaving
		}
		exitedFromTunnel.signalAll();
		lock.unlock();
	}
	
	private void makePriorityLists() {
		priority = new ArrayList<ArrayList<Vehicle>>();
		for (int i = 0; i < 5; i++) {
			priority.add(new ArrayList<>());
		}
	}
	private boolean checkTunnels(Vehicle vehicle) {
		for (Tunnel tunnel : tunnels) {
			if (!this.tunnelsWithAmb.contains(tunnel)&&tunnel.tryToEnterInner(vehicle)) {// use try to enter/exit inner
				// add to tunnel map
				vehicleMap.put(vehicle, tunnel);// if it enters the tunnel remember which tunnel
				if(vehicle instanceof Ambulance) {
					System.out.println("AMB");
					this.tunnelsWithAmb.add(tunnel);
					ambConditions.get(ambLocks.get(tunnel)).get(0).signalAll();//wake up all in the associated tunnel
				}else {
					addLockConditionsToVehicle(vehicle, tunnel);
				}
				return true;
			}
		}
		return false;
	}

	private void generateLockConditions(Tunnel tunnel) {
		Lock lock = new ReentrantLock();
		ArrayList<Condition> ambConds = new ArrayList<>();
		ambConds.add(0, lock.newCondition());//entry condition
		ambConds.add(1, lock.newCondition());//exit condition
		this.ambLocks.put(tunnel, lock);
		this.ambConditions.put(lock, ambConds);
	}
	
	private void addLockConditionsToVehicle(Vehicle vehicle, Tunnel tunnel) {
		Lock lock = this.ambLocks.get(tunnel);
		ArrayList<Condition> condList = this.ambConditions.get(lock);
		vehicle.setLockConditions(lock,condList.get(0),condList.get(1));
	}
	
	private boolean checkHighPrior(int curr) {
		for (int i = 4; i > curr; i--) {
			if (!priority.get(i).isEmpty()) {
				return false;// if not empty return false
			}
		}
		return true;// if all before are true return true
	}
	

	
}

